import React from 'react'

function Loader() {
  return (
    <div>Loader</div>
  )
}

export default Loader