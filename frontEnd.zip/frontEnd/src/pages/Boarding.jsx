import React from 'react'

function Boarding() {
  return (
    <div>
        
    </div>
  )
}

export default Boarding